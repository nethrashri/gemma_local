# Smart RAG WiFi Analyzer - Complete Project

A unified AI system that intelligently handles WiFi, network, and home automation questions using RAG (Retrieval-Augmented Generation) with automatic fallback to general AI knowledge.

## Project Structure

```
smart-rag-wifi-analyzer/
├── rag_gemma_script.py          # Python script for Gemma + RAG processing
├── rag_gemma_server.js          # Node.js Express server
├── rag-wifi-mobile.html         # Mobile-friendly web interface
├── wifi-reference-document.md   # Default WiFi reference document
├── package.json                 # Node.js dependencies
├── requirements.txt             # Python dependencies
└── README.md                    # This setup guide
```

## Key Features

- **Smart Unified Mode**: Automatically detects topic relevance and chooses best response method
- **Topic Detection**: Recognizes WiFi/network/automation questions vs out-of-scope queries
- **RAG Priority**: Uses document context when available and relevant
- **AI Fallback**: Falls back to general AI knowledge for relevant topics not in documents
- **Out-of-Scope Detection**: Politely declines unrelated questions
- **Mobile Support**: Responsive web interface works on all devices
- **No Upload Required**: Works immediately without requiring document upload

## Quick Start

### 1. Prerequisites
- Node.js (v16 or higher)
- Python 3.8+ with pip
- Hugging Face account (for model access)

### 2. Create Project Directory
```bash
mkdir smart-rag-wifi-analyzer
cd smart-rag-wifi-analyzer
```

### 3. Save All Files
Copy all the provided files into your project directory:
- `rag_gemma_script.py`
- `rag_gemma_server.js`
- `rag-wifi-mobile.html`
- `wifi-reference-document.md`
- `package.json`
- `requirements.txt`

### 4. Install Dependencies

**Install Node.js dependencies:**
```bash
npm install
```

**Install Python dependencies:**
```bash
pip install -r requirements.txt
```

### 5. Configuration

**Update Python Path** in `rag_gemma_server.js` line 27:
```javascript
const PYTHON_PATH = '/Users/nethrashri/anaconda3/bin/python';
```

Find your Python path:
```bash
which python3
# or
which python
```

**Update Hugging Face Token** in `rag_gemma_script.py` line 9:
```python
os.environ['HF_TOKEN'] = 'your_huggingface_token_here'
```

**Update Cache Directory** in `rag_gemma_script.py` line 19:
```python
cache_dir = "/your/path/to/.cache/huggingface/hub"
```

**For Mobile Access** update `rag-wifi-mobile.html` line 423:
```javascript
const API_BASE = 'http://YOUR_IP_ADDRESS:3000';
```

Find your IP:
```bash
# macOS/Linux:
ifconfig | grep inet

# Windows:
ipconfig
```

### 6. Start the Server
```bash
npm start
# or
node rag_gemma_server.js
```

### 7. Access the Application

**Local:**
```
http://localhost:3000/mobile
```

**Mobile:**
```
http://YOUR_IP_ADDRESS:3000/mobile
```

## How Smart Mode Works

### Query Processing Flow
1. **User asks question** → System receives query
2. **Topic Detection** → Checks if WiFi/network/automation related
3. **If Relevant**:
   - Try RAG with document context (if available)
   - If no good document match → Use general AI knowledge
4. **If Not Relevant**: "Out of scope" response

### Smart Decision Tree
```
User Query
    ├── Topic Relevant?
    │   ├── YES → Document Available?
    │   │   ├── YES → Good Context Match?
    │   │   │   ├── YES → RAG Response
    │   │   │   └── NO → General AI Response
    │   │   └── NO → General AI Response
    │   └── NO → "Out of Scope" Response
```

## API Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/mobile` | GET | Serve mobile web interface |
| `/health` | GET | Check system status |
| `/api/smart-query` | POST | **Main endpoint - Smart unified query** |
| `/api/upload-document` | POST | Upload and process documents |
| `/api/load-default-document` | POST | Load built-in WiFi guide |
| `/api/document-status` | GET | Check document processing status |

## Testing Examples

### Should Work (WiFi/Network Related)
- "My WiFi keeps dropping"
- "How to fix slow internet speed"
- "Best router settings for gaming"
- "Cannot access YouTube"
- "Network security best practices"
- "Smart home automation setup"

### Should Say "Out of Scope"
- "How to cook pasta"
- "What's the weather today"
- "Capital of France"
- "Movie recommendations"

## Document Enhancement

### Load Default Document
1. Go to "Status" tab in interface
2. Click "Load Default WiFi Guide"
3. Wait for processing to complete

### Upload Custom Document
1. Go to "Document" tab
2. Upload file or paste text
3. Click "Process Document"
4. System will automatically use it when relevant

## Troubleshooting

### Common Issues

**1. Python Path Error:**
```bash
# Find correct path
which python3
# Update PYTHON_PATH in rag_gemma_server.js
```

**2. Missing Dependencies:**
```bash
pip install torch transformers sentence-transformers scikit-learn numpy huggingface-hub
```

**3. Model Download Issues:**
First run downloads ~555MB Gemma model. Ensure:
- Internet connection
- Valid Hugging Face token
- Sufficient disk space (2GB recommended)

**4. Mobile Access Issues:**
- Check firewall allows port 3000
- Verify IP address in mobile interface
- Ensure devices on same network

**5. Out of Scope for Valid Questions:**
If valid WiFi questions are marked "out of scope":
- Check keyword list in `rag_gemma_script.py` line 66
- Add relevant keywords to `wifi_keywords` array
- Lower similarity threshold in line 92

### Performance Notes
- **First query**: 30-60 seconds (model loading)
- **Subsequent queries**: 5-15 seconds
- **Document processing**: 10-30 seconds
- **Smart detection**: < 1 second

## Customization

### Add Keywords
Edit `wifi_keywords` array in `rag_gemma_script.py` to expand topic detection.

### Adjust Similarity Threshold
Modify line 92 in `rag_gemma_script.py`:
```python
relevant_chunks = [chunks[i] for i in top_indices if similarities[i] > 0.1]  # Lower = more inclusive
```

### Change Response Style
Modify prompts in `rag_gemma_script.py` around lines 120 and 138.

## Architecture

**Frontend**: HTML5 + CSS3 + Vanilla JavaScript
**Backend**: Node.js + Express
**AI Model**: Google Gemma 3-270M (local)
**Embeddings**: SentenceTransformer (all-MiniLM-L6-v2)
**Vector Search**: Cosine similarity with scikit-learn
**Document Processing**: Text chunking with overlap

## Security

- Runs completely locally
- No external API calls during operation
- Documents stored in memory only
- Cleared on server restart
- No sensitive data logging

## License

MIT License - Feel free to modify and distribute.

## Support

For issues:
1. Check troubleshooting section
2. Verify all dependencies installed
3. Confirm configuration paths are correct
4. Check console logs for error messages

## Development Notes

**Model Requirements:**
- Gemma 3-270M-it model (~555MB)
- SentenceTransformer model (~90MB)
- Total disk space: ~2GB recommended

**Performance Tuning:**
- Adjust `max_tokens` for longer/shorter responses
- Modify chunk size in `chunk_document()` function
- Change similarity threshold for more/less strict matching

**Extending Functionality:**
- Add new keywords to topic detection
- Create additional document categories
- Implement user authentication
- Add conversation history

## File Descriptions

**Core Files:**
- `rag_gemma_script.py` - Main AI processing with smart mode logic
- `rag_gemma_server.js` - Express server with API endpoints
- `rag-wifi-mobile.html` - Responsive web interface

**Configuration:**
- `package.json` - Node.js project configuration
- `requirements.txt` - Python dependencies
- `wifi-reference-document.md` - Default knowledge base

**Key Functions:**
- `is_topic_relevant()` - Determines if query is WiFi/network related
- `smart_generate()` - Main unified processing mode
- `callSmartGemma()` - Server-side smart query handler
- `find_relevant_context()` - Vector similarity search

This system provides an intelligent, unified approach to WiFi troubleshooting that automatically adapts to user queries while maintaining clear boundaries on topic relevance.