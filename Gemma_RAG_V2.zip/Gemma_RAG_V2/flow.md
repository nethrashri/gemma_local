RAG Workflow - Step by Step
1. Document Processing Phase
When you upload a document or load the default WiFi guide:
In rag_gemma_script.py (process_document mode):
python# Document gets chunked into smaller pieces
chunks = chunk_document(document_text)  # Splits into ~500 char chunks
embeddings = create_embeddings(chunks)  # Converts to vector embeddings
Storage: Document chunks and embeddings stored in server memory (documentStore)
2. Query Processing Phase
When you ask a question, the smart mode workflow:
Step 1 - Topic Detection (is_topic_relevant()):
pythonwifi_keywords = ['wifi', 'network', 'router', 'internet', 'connection', ...]
query_lower = query.lower()
return any(keyword in query_lower for keyword in wifi_keywords)
Step 2 - Context Retrieval (find_relevant_context()):
python# Convert your question to embeddings
query_embedding = embedding_model.encode([query])

# Calculate similarity with document chunks
similarities = cosine_similarity(query_embedding, embeddings)[0]

# Get most relevant chunks (similarity > 0.1 threshold)
relevant_chunks = [chunks[i] for i in top_indices if similarities[i] > 0.1]
3. RAG Decision Logic
In smart_generate mode:
pythonif relevant_context and max_similarity > 0.15:
    # USE RAG MODE - Document context found
    context_text = "\n\n".join(relevant_context)
    prompt = f"""You are a WiFi expert. Based on this documentation:
    {context_text}
    
    User Question: {query}
    Answer based on the documentation:"""
    
else:
    # FALLBACK TO GENERAL AI - No good document match
    prompt = f"""You are a WiFi expert. Answer this question:
    {query}
    Provide troubleshooting steps:"""
4. Where Document Reference Happens
The RAG magic occurs in the prompt construction:
python# THIS IS WHERE YOUR DOCUMENT CONTENT GETS INJECTED
prompt = f"""Based on the technical documentation:

Technical Documentation:
{context_text}  # <-- YOUR DOCUMENT CHUNKS GO HERE

User's Question: {query}

Answer based on the documentation:"""
5. Visual Workflow
Your Question
    ↓
Topic Detection (WiFi related?)
    ↓ YES
Document Available?
    ↓ YES  
Convert Question → Embeddings
    ↓
Find Similar Document Chunks (cosine similarity)
    ↓
Similarity > 0.15?
    ↓ YES (RAG MODE)
Inject Document Chunks into Prompt
    ↓
Send Enhanced Prompt to Gemma
    ↓
AI Generates Answer Using Your Documents
6. How to Tell RAG is Being Used
In the web interface, look for:

Mode indicator shows "RAG" (green)
"Context Chunks Used: X" appears
Response references specific details from your documents

In server logs:
bashUsing RAG mode with 3 chunks (similarity: 0.847)
7. RAG vs General AI Example
RAG Response (uses your documents):
"Based on the documentation, for excellent signal optimization you should position the router centrally and use channels 1, 6, or 11 for 2.4 GHz..."
General AI Response (no document context):
"For WiFi troubleshooting, try restarting your router, checking for interference..."
The key difference is RAG responses cite specific information from your uploaded documents, while general AI responses use the model's training knowledge.
The document content literally becomes part of the prompt sent to the AI model - that's how RAG works. Your documents provide the context that guides the AI's response.