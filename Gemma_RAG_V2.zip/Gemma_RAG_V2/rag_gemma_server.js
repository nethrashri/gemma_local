// rag_enhanced_gemma_server.js - Smart RAG-Enhanced WiFi Analysis API
const express = require('express');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json({ limit: '10mb' }));
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    next();
});

// Serve static files
app.use(express.static(__dirname));

// In-memory vector store for document chunks
let documentStore = {
    chunks: [],
    embeddings: [],
    metadata: {},
    isProcessed: false
};

// Python script path
const scriptPath = path.join(__dirname, 'rag_gemma_script.py');

// UPDATE YOUR PYTHON PATH HERE
const PYTHON_PATH = '/Users/nethrashri/anaconda3/bin/python';

// Function to call Python script for document processing
async function processDocument(documentText) {
    return new Promise((resolve, reject) => {
        let output = '';
        let errorOutput = '';

        console.log('Processing document for RAG...');

        const pythonProcess = spawn(PYTHON_PATH, 
            [scriptPath, 'process_document', documentText], 
            { stdio: ['pipe', 'pipe', 'pipe'] }
        );

        pythonProcess.stdout.on('data', (data) => {
            output += data.toString();
        });

        pythonProcess.stderr.on('data', (data) => {
            errorOutput += data.toString();
            console.log('Python log:', data.toString().trim());
        });

        pythonProcess.on('close', (code) => {
            if (code === 0) {
                try {
                    const lines = output.trim().split('\n');
                    const jsonLine = lines[lines.length - 1];
                    const result = JSON.parse(jsonLine);
                    
                    if (result.success) {
                        resolve(result);
                    } else {
                        reject(new Error(result.error));
                    }
                } catch (e) {
                    reject(new Error(`Parse error: ${e.message}. Output: ${output}`));
                }
            } else {
                reject(new Error(`Python failed (${code}): ${errorOutput}`));
            }
        });

        pythonProcess.on('error', (error) => {
            reject(new Error(`Process error: ${error.message}`));
        });

        setTimeout(() => {
            pythonProcess.kill();
            reject(new Error('Timeout during document processing'));
        }, 300000);
    });
}

// Function to call smart RAG (new unified mode)
async function callSmartGemma(query, maxTokens = 250) {
    return new Promise((resolve, reject) => {
        let output = '';
        let errorOutput = '';

        console.log(`Calling Smart Gemma: "${query.substring(0, 50)}..."`);

        // If no document is processed, use empty arrays
        const chunksJson = documentStore.isProcessed ? JSON.stringify(documentStore.chunks) : "[]";
        const embeddingsJson = documentStore.isProcessed ? JSON.stringify(documentStore.embeddings) : "[]";

        const pythonProcess = spawn(PYTHON_PATH, 
            [scriptPath, 'smart_generate', query, chunksJson, embeddingsJson, maxTokens.toString()], 
            { stdio: ['pipe', 'pipe', 'pipe'] }
        );

        pythonProcess.stdout.on('data', (data) => {
            output += data.toString();
        });

        pythonProcess.stderr.on('data', (data) => {
            errorOutput += data.toString();
            console.log('Python log:', data.toString().trim());
        });

        pythonProcess.on('close', (code) => {
            if (code === 0) {
                try {
                    const lines = output.trim().split('\n');
                    const jsonLine = lines[lines.length - 1];
                    const result = JSON.parse(jsonLine);
                    
                    if (result.success) {
                        resolve({
                            response: result.response,
                            model: result.model,
                            contextUsed: result.context_used,
                            mode: result.mode,
                            topicRelevant: result.topic_relevant
                        });
                    } else {
                        reject(new Error(result.error));
                    }
                } catch (e) {
                    reject(new Error(`Parse error: ${e.message}. Output: ${output}`));
                }
            } else {
                reject(new Error(`Python failed (${code}): ${errorOutput}`));
            }
        });

        pythonProcess.on('error', (error) => {
            reject(new Error(`Process error: ${error.message}`));
        });

        setTimeout(() => {
            pythonProcess.kill();
            reject(new Error('Timeout'));
        }, 120000);
    });
}

// Function to call RAG-enhanced Gemma (original)
async function callRagGemma(query, maxTokens = 250) {
    return new Promise((resolve, reject) => {
        let output = '';
        let errorOutput = '';

        console.log(`Calling RAG Gemma: "${query.substring(0, 50)}..."`);

        if (!documentStore.isProcessed) {
            reject(new Error('No document has been processed for RAG. Please upload a document first.'));
            return;
        }

        const chunksJson = JSON.stringify(documentStore.chunks);
        const embeddingsJson = JSON.stringify(documentStore.embeddings);

        const pythonProcess = spawn(PYTHON_PATH, 
            [scriptPath, 'rag_generate', query, chunksJson, embeddingsJson, maxTokens.toString()], 
            { stdio: ['pipe', 'pipe', 'pipe'] }
        );

        pythonProcess.stdout.on('data', (data) => {
            output += data.toString();
        });

        pythonProcess.stderr.on('data', (data) => {
            errorOutput += data.toString();
            console.log('Python log:', data.toString().trim());
        });

        pythonProcess.on('close', (code) => {
            if (code === 0) {
                try {
                    const lines = output.trim().split('\n');
                    const jsonLine = lines[lines.length - 1];
                    const result = JSON.parse(jsonLine);
                    
                    if (result.success) {
                        resolve({
                            response: result.response,
                            model: result.model,
                            contextUsed: result.context_used
                        });
                    } else {
                        reject(new Error(result.error));
                    }
                } catch (e) {
                    reject(new Error(`Parse error: ${e.message}. Output: ${output}`));
                }
            } else {
                reject(new Error(`Python failed (${code}): ${errorOutput}`));
            }
        });

        pythonProcess.on('error', (error) => {
            reject(new Error(`Process error: ${error.message}`));
        });

        setTimeout(() => {
            pythonProcess.kill();
            reject(new Error('Timeout'));
        }, 120000);
    });
}

// Regular Gemma call (backward compatibility)
async function callLocalGemma(prompt, maxTokens = 200) {
    return new Promise((resolve, reject) => {
        let output = '';
        let errorOutput = '';

        console.log(`Calling local Gemma: "${prompt.substring(0, 50)}..."`);

        const pythonProcess = spawn(PYTHON_PATH, 
            [scriptPath, 'generate', prompt, maxTokens.toString()], 
            { stdio: ['pipe', 'pipe', 'pipe'] }
        );

        pythonProcess.stdout.on('data', (data) => {
            output += data.toString();
        });

        pythonProcess.stderr.on('data', (data) => {
            errorOutput += data.toString();
            console.log('Python log:', data.toString().trim());
        });

        pythonProcess.on('close', (code) => {
            if (code === 0) {
                try {
                    const lines = output.trim().split('\n');
                    const jsonLine = lines[lines.length - 1];
                    const result = JSON.parse(jsonLine);
                    
                    if (result.success) {
                        resolve({
                            response: result.response,
                            model: result.model
                        });
                    } else {
                        reject(new Error(result.error));
                    }
                } catch (e) {
                    reject(new Error(`Parse error: ${e.message}. Output: ${output}`));
                }
            } else {
                reject(new Error(`Python failed (${code}): ${errorOutput}`));
            }
        });

        pythonProcess.on('error', (error) => {
            reject(new Error(`Process error: ${error.message}`));
        });

        setTimeout(() => {
            pythonProcess.kill();
            reject(new Error('Timeout'));
        }, 120000);
    });
}

// MOBILE ROUTE - Serve your mobile app
app.get('/mobile', (req, res) => {
    res.sendFile(path.join(__dirname, 'rag-wifi-mobile.html'));
});

// Root endpoint
app.get('/', (req, res) => {
    res.json({
        message: 'Smart RAG-Enhanced Local Gemma WiFi API',
        model: 'google/gemma-3-270m-it (555MB Local)',
        version: '4.0.0',
        features: ['Smart Unified Mode', 'Topic Detection', 'Auto RAG/AI Fallback', 'Mobile Support'],
        endpoints: {
            mobile: 'GET /mobile',
            health: 'GET /health',
            upload: 'POST /api/upload-document',
            smart_query: 'POST /api/smart-query',
            rag_query: 'POST /api/rag-query',
            process: 'POST /api/process-signal',
            status: 'GET /api/document-status'
        }
    });
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({
        status: 'running',
        model: 'google/gemma-3-270m-it (Local)',
        rag_enabled: true,
        smart_mode: true,
        document_processed: documentStore.isProcessed,
        document_chunks: documentStore.chunks.length,
        cache_location: '/Users/nethrashri/.cache/huggingface/hub/models--google--gemma-3-270m-it',
        endpoints: {
            mobile: '/mobile',
            upload: '/api/upload-document',
            smart_query: '/api/smart-query',
            rag_query: '/api/rag-query',
            process: '/api/process-signal',
            status: '/api/document-status'
        },
        timestamp: new Date().toISOString()
    });
});

// NEW: Smart query endpoint (unified RAG + General AI)
app.post('/api/smart-query', async (req, res) => {
    try {
        const { query, max_tokens = 300 } = req.body;

        if (!query || typeof query !== 'string') {
            return res.status(400).json({
                success: false,
                error: 'Missing or invalid query'
            });
        }

        const startTime = Date.now();
        const result = await callSmartGemma(query, max_tokens);
        const processingTime = Date.now() - startTime;

        res.json({
            success: true,
            query: query,
            response: result.response.replace(/^["']|["']$/g, '').trim(),
            context_chunks_used: result.contextUsed,
            processing_mode: result.mode, // 'rag', 'general', or 'out_of_scope'
            topic_relevant: result.topicRelevant,
            metadata: {
                model: result.model,
                processing_time_ms: processingTime,
                document_available: documentStore.isProcessed,
                document_name: documentStore.isProcessed ? documentStore.metadata.name : null,
                total_chunks_available: documentStore.chunks.length,
                timestamp: new Date().toISOString()
            }
        });

        console.log(`Smart response generated in ${processingTime}ms using ${result.mode} mode with ${result.contextUsed} context chunks`);

    } catch (error) {
        console.error('Smart query error:', error.message);
        res.status(500).json({
            success: false,
            error: 'Smart query failed',
            message: error.message
        });
    }
});

// Document upload and processing endpoint
app.post('/api/upload-document', async (req, res) => {
    try {
        const { document_text, document_name = 'Uploaded Document' } = req.body;

        if (!document_text || typeof document_text !== 'string') {
            return res.status(400).json({
                success: false,
                error: 'Missing or invalid document text'
            });
        }

        console.log(`Processing document: ${document_name} (${document_text.length} characters)`);
        
        const startTime = Date.now();
        const result = await processDocument(document_text);
        const processingTime = Date.now() - startTime;

        // Store in memory
        documentStore = {
            chunks: result.chunks,
            embeddings: result.embeddings,
            metadata: {
                name: document_name,
                processed_at: new Date().toISOString(),
                chunk_count: result.chunk_count,
                character_count: document_text.length
            },
            isProcessed: true
        };

        res.json({
            success: true,
            message: 'Document processed successfully',
            document_info: {
                name: document_name,
                chunks_created: result.chunk_count,
                processing_time_ms: processingTime
            },
            rag_status: 'ready'
        });

    } catch (error) {
        console.error('Document processing error:', error.message);
        res.status(500).json({
            success: false,
            error: 'Document processing failed',
            message: error.message
        });
    }
});

// RAG query endpoint (original - for backward compatibility)
app.post('/api/rag-query', async (req, res) => {
    try {
        const { query, max_tokens = 300 } = req.body;

        if (!query || typeof query !== 'string') {
            return res.status(400).json({
                success: false,
                error: 'Missing or invalid query'
            });
        }

        if (!documentStore.isProcessed) {
            return res.status(400).json({
                success: false,
                error: 'No document processed',
                message: 'Please upload a document first using /api/upload-document'
            });
        }

        const startTime = Date.now();
        const result = await callRagGemma(query, max_tokens);
        const processingTime = Date.now() - startTime;

        res.json({
            success: true,
            query: query,
            response: result.response.replace(/^["']|["']$/g, '').trim(),
            context_chunks_used: result.contextUsed,
            metadata: {
                model: result.model,
                processing_time_ms: processingTime,
                document_name: documentStore.metadata.name,
                total_chunks_available: documentStore.chunks.length,
                timestamp: new Date().toISOString()
            }
        });

        console.log(`RAG response generated in ${processingTime}ms using ${result.contextUsed} context chunks`);

    } catch (error) {
        console.error('RAG query error:', error.message);
        res.status(500).json({
            success: false,
            error: 'RAG query failed',
            message: error.message
        });
    }
});

// Document status endpoint
app.get('/api/document-status', (req, res) => {
    res.json({
        success: true,
        document_processed: documentStore.isProcessed,
        document_info: documentStore.isProcessed ? {
            name: documentStore.metadata.name,
            processed_at: documentStore.metadata.processed_at,
            chunks: documentStore.metadata.chunk_count,
            characters: documentStore.metadata.character_count
        } : null,
        rag_ready: documentStore.isProcessed,
        smart_mode_available: true
    });
});

// Load default WiFi document endpoint
app.post('/api/load-default-document', async (req, res) => {
    try {
        // Load the default WiFi reference document
        const defaultDocPath = path.join(__dirname, 'wifi-reference-document.md');
        
        let defaultDocument;
        try {
            defaultDocument = fs.readFileSync(defaultDocPath, 'utf8');
        } catch (fileError) {
            // If file doesn't exist, use embedded document
            defaultDocument = `# WiFi Management, Network Security & Home Automation Reference Guide

## WiFi Network Management

### Router Placement Guidelines
- Central Location: Position the router in the center of your home for optimal coverage
- Elevation: Place router 4-6 feet above ground level on a shelf or mounted on wall
- Avoid Obstacles: Keep away from walls, metal objects, and electronic devices
- Ventilation: Ensure adequate airflow around the router to prevent overheating
- Distance from Interference: Maintain 3-foot minimum distance from microwaves, baby monitors, and Bluetooth devices

### Frequency Band Selection
- 2.4 GHz Band: Range up to 150 feet indoors, speed up to 150 Mbps, best for IoT devices
- 5 GHz Band: Range up to 50 feet indoors, speed up to 1 Gbps, best for streaming and gaming
- 6 GHz Band (WiFi 6E): Range 30-40 feet indoors, speed up to 9.6 Gbps, latest devices only

### Signal Optimization
- Channel Management: Use automatic channel selection or manually select channels 1, 6, or 11 for 2.4 GHz
- Quality of Service (QoS): Prioritize gaming devices and streaming equipment
- Bandwidth Allocation: Reserve minimum bandwidth for critical devices

## Network Security Best Practices

### Authentication and Access Control
- WPA3 Protocol: Use WPA3-Personal for home networks
- Password Security: Minimum 12 characters with mixed case, numbers, and symbols
- Password Rotation: Change WiFi passwords every 90 days
- Guest Network: Create separate network for visitors with limited access

### Firewall and Protection
- Enable SPI (Stateful Packet Inspection) firewall
- Configure router-level VPN for traffic encryption
- Enable DDoS protection and intrusion detection
- Monitor traffic for unusual bandwidth usage patterns

## Home Automation Integration

### Smart Home Network Architecture
- Bandwidth Planning: Allocate 1-5 Mbps per 4K streaming device
- Latency Requirements: Maintain <50ms latency for real-time control
- Device Categories: Security systems, climate control, lighting, entertainment
- Protocol Integration: WiFi 6/6E, Zigbee 3.0, Z-Wave Plus, Thread/Matter

### Troubleshooting Common Issues
- Connection Problems: Verify passwords, check MAC filtering, reset network settings
- Speed Issues: Run speed tests, check for background applications, verify QoS settings
- High Latency: Switch to 5 GHz band, enable gaming mode, close unnecessary applications
- Dropping Connections: Check for interference, update drivers, restart router
- Cannot Access Websites: Check DNS settings, try alternative DNS servers, verify internet connection`;
        }

        console.log('Loading default WiFi reference document...');
        
        const startTime = Date.now();
        const result = await processDocument(defaultDocument);
        const processingTime = Date.now() - startTime;

        // Store in memory
        documentStore = {
            chunks: result.chunks,
            embeddings: result.embeddings,
            metadata: {
                name: 'WiFi Management & Network Security Reference',
                processed_at: new Date().toISOString(),
                chunk_count: result.chunk_count,
                character_count: defaultDocument.length
            },
            isProcessed: true
        };

        res.json({
            success: true,
            message: 'Default WiFi reference document loaded successfully',
            document_info: {
                name: 'WiFi Management & Network Security Reference',
                chunks_created: result.chunk_count,
                processing_time_ms: processingTime
            },
            rag_status: 'ready'
        });

    } catch (error) {
        console.error('Default document loading error:', error.message);
        res.status(500).json({
            success: false,
            error: 'Failed to load default document',
            message: error.message
        });
    }
});

// Legacy WiFi signal processing endpoint (backward compatibility)
app.post('/api/process-signal', async (req, res) => {
    try {
        const { signal_status, custom_prompt, max_tokens = 250, use_rag = false } = req.body;

        if (!signal_status && !custom_prompt) {
            return res.status(400).json({
                error: 'Missing input',
                message: 'Provide signal_status or custom_prompt'
            });
        }

        let prompt;
        if (signal_status) {
            const signal = signal_status.signal || 'unknown';
            prompt = `You are a WiFi network specialist. Analyze this signal and provide recommendations:

WiFi Signal: "${signal}"

Provide:
1. Signal quality assessment  
2. Potential issues
3. Improvement recommendations
4. Technical actions

Keep response practical and actionable.`;
        } else {
            prompt = custom_prompt;
        }

        const startTime = Date.now();
        
        let result;
        if (use_rag && documentStore.isProcessed) {
            // Use RAG-enhanced response
            result = await callRagGemma(prompt, max_tokens);
            result.rag_used = true;
        } else {
            // Use regular Gemma response
            result = await callLocalGemma(prompt, max_tokens);
            result.rag_used = false;
        }
        
        const processingTime = Date.now() - startTime;

        res.json({
            success: true,
            input_data: {
                signal_status: signal_status || null,
                custom_prompt: custom_prompt || null,
                rag_enabled: use_rag && documentStore.isProcessed
            },
            analysis: result.response.replace(/^["']|["']$/g, '').trim(),
            metadata: {
                model: result.model,
                model_location: 'Local Cache',
                processing_time_ms: processingTime,
                rag_used: result.rag_used,
                context_chunks_used: result.contextUsed || 0,
                timestamp: new Date().toISOString()
            }
        });

        console.log(`Response generated in ${processingTime}ms using ${result.model}${result.rag_used ? ' with RAG' : ''}`);

    } catch (error) {
        console.error('Processing error:', error.message);
        res.status(500).json({
            success: false,
            error: 'Processing failed',
            message: error.message
        });
    }
});

// Start server on all interfaces (important for mobile access)
app.listen(PORT, '0.0.0.0', () => {
    console.log('=====================================');
    console.log(' Smart RAG-Enhanced Local Gemma WiFi API');
    console.log(' WITH UNIFIED SMART MODE');
    console.log('=====================================');
    console.log(` Port: ${PORT}`);
    console.log(` Health: http://localhost:${PORT}/health`);
    console.log(` Smart Query: POST http://localhost:${PORT}/api/smart-query`);
    console.log(` Upload Doc: POST http://localhost:${PORT}/api/upload-document`);
    console.log(` Mobile App: http://localhost:${PORT}/mobile`);
    console.log('=====================================');
    console.log(' MOBILE ACCESS:');
    console.log('1. Find your IP address: ifconfig | grep inet');
    console.log('2. Access from mobile: http://YOUR_IP:3000/mobile');
    console.log('=====================================');
    console.log(' SMART MODE FEATURES:');
    console.log('- Auto topic detection for WiFi/network questions');
    console.log('- RAG when document context available');
    console.log('- General AI fallback for relevant topics');
    console.log('- Out-of-scope detection for unrelated questions');
    console.log(' Works immediately - no document upload required!');
    console.log(` Python: ${PYTHON_PATH}`);
    console.log(' Cache: /Users/nethrashri/.cache/huggingface/hub/models--google--gemma-3-270m-it');
});

